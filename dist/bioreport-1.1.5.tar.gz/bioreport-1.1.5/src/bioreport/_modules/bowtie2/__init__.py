"""A module for reports produced by Bismark."""

from .bowtie2 import BioReportModule
