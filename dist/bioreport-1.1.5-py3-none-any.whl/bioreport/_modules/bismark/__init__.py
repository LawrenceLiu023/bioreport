"""A module for reports produced by Bismark."""

from .bismark import BioReportModule
