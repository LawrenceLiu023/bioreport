"""A module for reports produced by fastp."""

from .fastp import BioReportModule
